# Contributing

Please note we have a **[code of conduct](https://github.com/zero-to-mastery/CodeofConduct)**, please follow it in all your interactions with the project.

## Pull Request Process

1. Please make sure to create a separate file with your solutions. **Put that file into the `Solutions` folder.**

2. After you've made your pull request, you will have to wait until a maintainer can merge your request. Please be patient, as most maintainers are volunteers.

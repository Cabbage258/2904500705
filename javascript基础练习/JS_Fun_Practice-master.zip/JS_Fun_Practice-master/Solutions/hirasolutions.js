// 1. Returns the argument
const identity = (arg) => arg;
identity('Hi, Im Hira');

//Sum of two numbers

const addNum = (one, two)
=> one + two;
addNum(one, two);

addNum(9,8);

//Takes two numbers and returns difference

const subNum = (one, two)
=> one - two;
subNum(one, two);

subNum(4,8); 

//Takes two numbers and returns product
const mulNum = (one, two)
=> one * two;
mulNum(one, two);

mulNum(4,8); 
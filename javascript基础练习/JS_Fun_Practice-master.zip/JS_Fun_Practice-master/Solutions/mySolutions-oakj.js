// write a function identity that takes an argument and returns that argument

const identity = (arg) => arg;
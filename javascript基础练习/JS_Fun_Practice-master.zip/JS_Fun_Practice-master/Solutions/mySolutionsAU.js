//to add two values
const addb = (a,b) => a+b;
console.log(addb(a,b));

//to subtract two values
const subb = (a,b) => a-b;
console.log(subb(a,b));

//to multiply two values
const mulb = (a,b) => a*b;
console.log(mulb(a,b));

//to find minimum of two values
const minb = (a, b) => (a<b)?a:b;
console.log(minb(a,b));

//to find greater of two values
const maxb = () => (a>b)?a:b;
console.log(maxb(a,b));